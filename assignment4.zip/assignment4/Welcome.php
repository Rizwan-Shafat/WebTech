<?php
session_start();

if(!isset($_SESSION["user"])) {
     header("location:Introduction.html");
} else {
    echo "<h1>Welcome ".$_SESSION["user"]."</h1>";
	echo "<a href ='sclose.php'>Logout</a>";
}
?>