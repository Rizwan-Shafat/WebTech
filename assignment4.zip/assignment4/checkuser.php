<?php
session_start();
$user = $_POST['user'];
$pass = $_POST['pass'];
if(!isset($_COOKIE[$user])) {
     echo "User Not Exist";
} else {
     if($_COOKIE[$user]==$pass)
	 {
		 $_SESSION["user"]=$user;
		 header("location:Welcome.php");
	 }
	 else
	 {
		 echo "</h1>Password Error</h1>";
	 }
}
?>